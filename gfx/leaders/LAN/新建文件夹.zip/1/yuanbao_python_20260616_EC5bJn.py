import os
from pathlib import Path

def force_rename_images_simple():
    # 获取当前目录
    current_dir = Path('.')
    
    # 收集所有图片文件（手动处理大小写）
    image_extensions = ['.png', '.jpg', '.jpeg']
    image_files = []
    
    for ext in image_extensions:
        image_files.extend(current_dir.glob(f'*{ext}'))
    
    # 按创建时间排序
    image_files.sort(key=lambda x: x.stat().st_ctime)
    
    # 先重命名为临时文件
    temp_files = []
    for i, img_path in enumerate(image_files):
        temp_name = f"temp_{i}{img_path.suffix}"
        img_path.rename(img_path.parent / temp_name)
        temp_files.append((temp_name, img_path.suffix))
    
    # 再重命名为最终名称
    for i, (temp_name, suffix) in enumerate(temp_files, 1):
        new_name = f"{i}{suffix.lower()}"
        temp_path = current_dir / temp_name
        new_path = current_dir / new_name
        
        # 强制覆盖
        if new_path.exists():
            new_path.unlink()  # 删除已存在的文件
        temp_path.rename(new_path)
        print(f"✓ {temp_name} → {new_name}")

if __name__ == "__main__":
    force_rename_images_simple()